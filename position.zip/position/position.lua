function error(player, msg)
    player:PrintToPlayer(msg);
    player:PrintToPlayer("position {x} {y} {z} {zone ID} {player} {rotation}");
end;

function onTrigger(player, arg1, arg2, arg3, arg4, arg5, arg6)
    local target;
    local zoneId;
    local x;
    local y;
    local z;
    local targ;
	local rotation;

    -- shift arguments depending on number passed
    if (arg5 ~= nil) then
        x = tonumber(arg1);
        y = tonumber(arg2);
        z = tonumber(arg3);
        zoneId = tonumber (arg4);
        target = arg5;
		rotation = tonumber(arg6);
    elseif (arg4 ~= nil) then
        x = tonumber(arg1);
        y = tonumber(arg2);
        z = tonumber(arg3);
        if (GetPlayerByName(arg4) == nil) then
            zoneId = tonumber (arg4);
        else
            target = arg4;
        end
    elseif (arg3 ~= nil) then
        x = tonumber(arg1);
        y = tonumber(arg2);
        z = tonumber(arg3);
		rotation = tonumber(arg6);
    elseif (arg1 ~= nil) then
        target = arg1;
    end

    -- validate target
    if (target == nil) then
        targ = player;
    else
        targ = GetPlayerByName(target);
        if (targ == nil) then
            error(player, string.format( "Player named '%s' not found!", target ) );
            return;
        end
    end

    -- validate zone
    if (zoneId ~= nil) then
        zoneId = tonumber(zoneId);
        if (zoneId == nil or zoneId < 0 or zoneId > 298) then
            error(player, "Invalid zone ID.");
            return;
        end
    end
end