Author: ReaperX, bangerang
Version: 1.0.7

Addon to automatically get and store elemental obis based on day/weather/storm 
conditions. The addon is triggered on day change, weather change, and scholar
storm buff gain and loss.

Command listing:

//obiaway, //obi, //ob, or //oa
  (h)elp   - display help information.
  (s)ort   - force obiaway to put away and get appropriate obis.
  (g)et [ (a)ll | (n)eeded ]   - get obi
  (p)ut [ (a)ll| u(n)needed ] [ sack | satchel | case | wardrobe]  - put obi. location optional
  (l)ock [ on | off ]  - lock obi sorting
  (n)otify [ on | off ]   - sets notifications on or off.
  (loc)ation [ sack | satchel | case | wardrobe]   - sets where to put obis away.
