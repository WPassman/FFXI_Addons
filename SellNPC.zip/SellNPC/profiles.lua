-- Add items to existing profiles or create your own to sell groups of items using alias commands
local profiles = {}

-- //sellnpc powder
profiles['powder'] = S{
    'prize powder',
    }

-- //sellnpc ore
profiles['ore'] = S{
    'iron ore',
    'copper ore',
    'tin ore',
    }

-- //sellnpc junk
profiles['junk'] = S{
    'chestnut',
    'san d\'Or. carrot',
    }

return profiles