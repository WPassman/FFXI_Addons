Information:
* Author: Selindrile
* Thanks to: Arcon, sorry for abusing your code. :<
* Addon created to make Send more useful in terms of targetting, may require a loaded gearswap user file.

Abbreviation: //sat, //sendalltarget

Commands:
* //sat alltarget - All boxes on this computer target whatever the sender is targetting.
* //sat youtarget charactername - Box named "charactername" targets whatever the sender is targetting.
* //sat target - This box targets the ID provided.
* //sat allcommand action - All boxes on this computer perform "action" on sender's target.
* //sat youcommand charactername action - "charactername" performs "action" on sender's target.
* //sat attack - This box attacks the ID provided.
* //sat allattack - All boxes on this computer attack the sender's target.
* //sat youattack charactername action - "charactername" attacks the sender's target.