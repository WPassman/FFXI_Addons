Addon Command:

/npcit item

Will sell all instances of item found in inventory.
No quotes are needed around item name, also accepts auto translate terms.
You must open sales menu once on zoning, will queue all commands inside or
outside menu, so it's possible to store a list of items before approaching npc,
simply do "/npcit" after clicking on npc to sell items in queue.
Items are removed from queue after all instances found are sold.
Will ignore items equipped, in bazaar or that can not be sold to NPC vendors.
