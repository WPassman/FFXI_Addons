With this addon loaded, just click on any brown treasure casket and it
will display info about possible combinations, the best number to guess
and the worst case chance of guessing correctly.

This addon was ported to ashita from windowers repository by Ivaar.

Issues should be reported here https://github.com/Ivaar/Ashita-addons/issues
