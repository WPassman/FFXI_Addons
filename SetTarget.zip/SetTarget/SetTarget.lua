local packets = require('packets')

_addon.name = 'SetTarget'
_addon.author = 'Arcon & Sphinx'
_addon.commands = {'settarget', 'st'}
_addon.version = '1.1.0.1'
require('luau')
require('functions')
windower.register_event('addon command', function(...)
    local id = T{...}:concat(" ")
    id = tonumber(id) or id:lower()
    local target
    if type(id) == 'string' then
        local mobs = T(windower.ffxi.get_mob_list()):filter(string.startswith-{id}..string.lower)
        local distances = T{}
        for _,key in mobs:it() do
            if type(key) == 'number' then
                local mob = windower.ffxi.get_mob_by_index(key)
                local distance = mob and mob.distance
                if distance then
                    distances[key] = distance
                end
            end
        end
        index = distances:find(distances:min())
        target = index and windower.ffxi.get_mob_by_index(index)
    else 
        target = windower.ffxi.get_mob_by_id(id)
    end
	
	if id == target.id then
	windower.send_command('wait 1;input /ja "Provoke" <t>')	
    elseif not target then
        return
	end


    local player = windower.ffxi.get_player()
    if not player then
        return
    end
    packets.inject(packets.new('incoming', 0x058, {
        ['Player'] = player.id,
        ['Target'] = target.id,
        ['Player Index'] = player.index,
    }))
end)